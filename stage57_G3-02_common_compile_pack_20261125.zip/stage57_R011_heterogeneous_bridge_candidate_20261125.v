(* Candidate only. Exact literal; preserves verified implementation order. *)
Require Import Coq.Strings.String.
Require Import stage57_U1_heterogeneous_partial_candidate_20261125.
Require Import stage57_R011_binding_candidate_20261125.
Require Import stage57_R011_literal_contract_candidate_20261125.
Open Scope string_scope.
Definition lookup_R011 (env : field_env) (_ : string) : option field_binding := env "f".
Definition eval_binding_R011 (s : string) (b : field_binding) :=
  match b with existT g ev => run_R011 s g ev end.
Lemma R011_typed_composition_agrees : forall env s,
  typed_compose (lookup_R011 env) (eval_binding_R011 s) s = run_bound_R011 env s.
Proof. intros env s. reflexivity. Qed.
Lemma R011_typed_lookup_failure : forall env s,
  env "f" = None -> run_bound_R011 env s = None.
Proof. intros env s H. apply bound_missing_name. exact H. Qed.
Print Assumptions R011_typed_composition_agrees.
Print Assumptions R011_typed_lookup_failure.
