(* G3-02 candidate, not compiled. Exact registered literal only.
   f is supplied by the caller; this is not a verified environment lookup.
   None means missing evidence or literal mismatch, not non-differentiability. *)
Require Import Coq.Strings.String.
Require Import stage57_R011_field_bridge_candidate_20261125.
Require Import stage57_R011_derivative_contract_candidate_20261125.
Open Scope string_scope.
Module F := R011_Field_Bridge.
Definition run_R011 (s : string) (f : F.scalar_field)
  (evidence : option (partials_exist f)) : option F.vector_field :=
  if string_dec s "GRAD(f)" then
    match evidence with
    | Some H => Some (grad3 f H)
    | None => None
    end
  else None.
Lemma R011_missing_evidence : forall s f, run_R011 s f None = None.
Proof. intros s f. unfold run_R011. destruct (string_dec s "GRAD(f)"); reflexivity. Qed.
Lemma R011_wrong_literal : forall s f e, s <> "GRAD(f)" -> run_R011 s f e = None.
Proof. intros s f e H. unfold run_R011. destruct (string_dec s "GRAD(f)"); [contradiction|reflexivity]. Qed.
Lemma R011_exact_with_evidence : forall f (H : partials_exist f),
  run_R011 "GRAD(f)" f (Some H) = Some (grad3 f H).
Proof. intros f H. unfold run_R011. destruct (string_dec "GRAD(f)" "GRAD(f)"); [reflexivity|contradiction]. Qed.
Print Assumptions R011_missing_evidence.
Print Assumptions R011_wrong_literal.
Print Assumptions R011_exact_with_evidence.
