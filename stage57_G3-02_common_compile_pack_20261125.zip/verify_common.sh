#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
sha256sum -c SHA256SUMS
run=$(mktemp -d "$PWD/run.XXXXXXXX")
cp -- *.v compile_order.txt SHA256SUMS "$run/"
cd "$run"
mkdir logs
opam exec -- coqc --version | tee logs/version.txt
opam list --installed --columns=name,version > logs/opam.txt
grep -q 'version 8\.18\.0' logs/version.txt
grep -Eq '^coq-coquelicot[[:space:]]+3\.4\.5([[:space:]]|$)' logs/opam.txt
while IFS= read -r f; do
  echo "COMPILE $f"
  opam exec -- coqc "$f.v" > "logs/$f.coqc.log" 2>&1 || { tail -n 30 "logs/$f.coqc.log"; exit 1; }
  test -s "$f.vo"
done < compile_order.txt
# Checking the two targets also traverses their imported modules.
for f in stage57_U1_heterogeneous_partial_candidate_20261125 stage57_R011_heterogeneous_bridge_candidate_20261125; do
  opam exec -- coqchk "$f" > "logs/$f.coqchk.log" 2>&1 || { tail -n 30 "logs/$f.coqchk.log"; exit 1; }
  grep -F 'Modules were successfully checked' "logs/$f.coqchk.log"
  cat "logs/$f.coqc.log"
done
sha256sum -c SHA256SUMS
sha256sum *.v *.vo logs/* > SHA256SUMS_results.txt
sha256sum -c SHA256SUMS_results.txt >/dev/null
printf 'PASS: two targets; %s\n' "$run"
