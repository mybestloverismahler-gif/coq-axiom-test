Require Import stage57_R033_partial_bridge_candidate_20261124.
Module P := stage57_R033_partial_bridge_candidate_20261124.

Section TypedComposition.
Context {A B C : Type}.
Variables (q : A -> option B) (p : B -> option C).
Definition typed_compose (x : A) : option C :=
  match q x with Some y => p y | None => None end.

Theorem typed_success_exact : forall x v,
  typed_compose x = Some v <->
  exists y, q x = Some y /\ p y = Some v.
Proof.
  intros x v. unfold typed_compose. split.
  - destruct (q x) as [y|] eqn:H.
    + intro K. exists y. split; [reflexivity | exact K].
    + discriminate.
  - intros [y [H K]]. rewrite H. exact K.
Qed.
Theorem typed_failure_blocks : forall x,
  q x = None -> typed_compose x = None.
Proof. intros x H. unfold typed_compose. rewrite H. reflexivity. Qed.
End TypedComposition.

Theorem typed_legacy_agreement : forall (A : Type)
  (q p : A -> option A) (x : A),
  typed_compose q p x = P.compose_partial p q x.
Proof. reflexivity. Qed.
Print Assumptions typed_success_exact.
Print Assumptions typed_failure_blocks.
Print Assumptions typed_legacy_agreement.
