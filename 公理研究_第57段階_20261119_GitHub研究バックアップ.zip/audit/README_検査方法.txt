研究ソースの作業ツリーとGit全履歴bundleの保存。git未追跡ファイルも収録。
Coq生成物(.vo/.vos/.vok/.glob/.aux)、Git作業用内部ディレクトリ.git、cacheは除外。
従って、作業ディレクトリをバイト単位で完全複製したものではない。
作業ツリーはworktree/、Git履歴はgit_history_all_refs.bundle。
各ファイルのSHA256はaudit/worktree_sha256.txt。
Git履歴の復元例: git clone git_history_all_refs.bundle <new-directory>
このコマンドはリポジトリを変更したりgit commit/pushしたりしない。
iCloud保存は利用者がiPad「ファイル」アプリから行い、存在を確認する。
