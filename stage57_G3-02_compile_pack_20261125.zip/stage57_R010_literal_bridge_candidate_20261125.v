Require Import Coq.Strings.String.
Require Import Coq.Lists.List.
Require Import stage57_R010_DEL_parser_20261121.
Require Import stage57_R010_DEL_token_audit_20261121.
Open Scope string_scope.
Module RP := stage57_R010_DEL_parser_20261121.
Module RT := stage57_R010_DEL_token_audit_20261121.
Definition decode_R010 (s : string) : option (list RT.extended_token) :=
  if string_dec s "DEL" then Some (RT.DEL :: nil) else None.
Definition parse_R010 (s : string) : option RP.extended_expr :=
  match decode_R010 s with
  | Some ts => RP.parse_extended ts
  | None => None
  end.
Theorem R010_exact_acceptance : forall s : string,
  parse_R010 s = Some RP.DELExpr <-> s = "DEL".
Proof.
  intro s. unfold parse_R010, decode_R010.
  destruct (string_dec s "DEL") as [H|H].
  - rewrite RP.DEL_accepted. split; intro E; [exact H|reflexivity].
  - split; intro E; [discriminate E|contradiction].
Qed.
Print Assumptions R010_exact_acceptance.
