(* G3-02 candidate only; not compiled. Exact literal GRAD(f).
   A caller-supplied typed environment is not a verified DB lookup.
   The field and its evidence are bound together, not passed independently. *)
Require Import Coq.Strings.String.
Require Import stage57_R011_field_bridge_candidate_20261125.
Require Import stage57_R011_derivative_contract_candidate_20261125.
Require Import stage57_R011_literal_contract_candidate_20261125.
Open Scope string_scope.
Module BF := R011_Field_Bridge.
Definition field_binding : Type :=
  { g : BF.scalar_field & option (partials_exist g) }.
Definition field_env := string -> option field_binding.
Definition run_bound_R011 (env : field_env) (s : string)
  : option BF.vector_field :=
  match env "f" with
  | Some (existT _ g ev) => run_R011 s g ev
  | None => None
  end.
Lemma bound_missing_name : forall env s,
  env "f" = None -> run_bound_R011 env s = None.
Proof. intros env s H. unfold run_bound_R011. rewrite H. reflexivity. Qed.
Lemma bound_missing_evidence : forall env s g,
  env "f" = Some (existT (fun h => option (partials_exist h)) g None) ->
  run_bound_R011 env s = None.
Proof. intros env s g H. unfold run_bound_R011. rewrite H. apply R011_missing_evidence. Qed.
Lemma bound_exact : forall env g (H : partials_exist g),
  env "f" = Some (existT (fun h => option (partials_exist h)) g (Some H)) ->
  run_bound_R011 env "GRAD(f)" = Some (grad3 g H).
Proof. intros env g H E. unfold run_bound_R011. rewrite E. apply R011_exact_with_evidence. Qed.
Lemma bound_wrong_literal : forall env s,
  s <> "GRAD(f)" -> run_bound_R011 env s = None.
Proof.
 intros env s H. unfold run_bound_R011.
 destruct (env "f") as [[g ev]|]; [apply R011_wrong_literal; exact H|reflexivity].
Qed.
Print Assumptions bound_missing_name.
Print Assumptions bound_missing_evidence.
Print Assumptions bound_exact.
Print Assumptions bound_wrong_literal.
