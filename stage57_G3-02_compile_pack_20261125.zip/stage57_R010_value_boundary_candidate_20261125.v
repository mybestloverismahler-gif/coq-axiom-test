(* G3-02: candidate, NOT compiled. No new axioms.
   A bare DEL is a recognized operator symbol, not a typed value in B.ty.
   None here means no value type in this restricted model, not invalid mathematics. *)
Require Import Coq.Strings.String.
Open Scope string_scope.
Require Import stage57_T3_T4_U1_candidate.
Require Import stage57_R010_DEL_parser_20261121.
Require Import stage57_R010_DEL_token_audit_20261121.
Require Import stage57_R010_literal_bridge_candidate_20261125.
Module B := stage57_T3_T4_U1_candidate.
Module RP := stage57_R010_DEL_parser_20261121.
Module RT := stage57_R010_DEL_token_audit_20261121.
Module LB := stage57_R010_literal_bridge_candidate_20261125.
Definition infer_value (e : RP.extended_expr) : option B.ty :=
  match e with
  | RP.LegacyExpr old => B.infer old
  | RP.DELExpr => None
  end.
Theorem legacy_type_preserved : forall e,
  infer_value (RP.LegacyExpr e) = B.infer e.
Proof. reflexivity. Qed.
Theorem bare_DEL_has_no_value_type : infer_value RP.DELExpr = None.
Proof. reflexivity. Qed.
Definition parse_value (s : String.string) : option B.ty :=
  match LB.parse_R010 s with
  | Some e => infer_value e
  | None => None
  end.
Theorem registered_DEL_not_a_value :
  parse_value "DEL" = None.
Proof. reflexivity. Qed.
Print Assumptions legacy_type_preserved.
Print Assumptions bare_DEL_has_no_value_type.
Print Assumptions registered_DEL_not_a_value.
