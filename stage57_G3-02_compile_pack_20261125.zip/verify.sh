#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c SHA256SUMS
mkdir -p logs
opam exec -- coqc --version | tee logs/version.txt
opam list --installed --columns=name,version | tee logs/opam.txt
grep -q '8.18.0' logs/version.txt || { echo 'Coq version mismatch'; exit 1; }
grep -Ei 'coquelicot[[:space:]]+3\.4\.5([[:space:]]|$)' logs/opam.txt || { echo 'Coquelicot version mismatch'; exit 1; }
while IFS= read -r f; do
  m=${f%.v}
  opam exec -- coqc "$f" 2>&1 | tee "logs/$m.coqc.log"
  opam exec -- coqchk "$m" 2>&1 | tee "logs/$m.coqchk.log"
done < compile_order.txt
sha256sum -c SHA256SUMS
# Successful compilation is not a closure decision. Review Print Assumptions logs.
