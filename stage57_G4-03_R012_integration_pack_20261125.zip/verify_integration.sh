#!/usr/bin/env bash
set -euo pipefail
root=/workspaces/coq-axiom-test
here=$(cd -- "$(dirname -- "$0")" && pwd)
cd "$here"
sha256sum -c SHA256SUMS
base="$root/R012_v3_check_20261125.WR1y9LtJ.zip"
echo "66ae03699c75bb7d171d5e09566a6fcde711e65d0a2fc14923e9cc45143fdd5b  $base" | sha256sum -c -
opam exec -- coqc --version | tee version_check.txt
grep -q 'version 8.18.0' version_check.txt
grep -q 'OCaml 4.14.1' version_check.txt
opam list --installed --columns=name,version | tee packages_check.txt
grep -Eq '^[[:space:]]*coq-coquelicot[[:space:]]+3\.4\.5([[:space:]]|$)' packages_check.txt
run=$(mktemp -d "$root/R012_integration_20261125.XXXXXXXX")
unzip -q "$base" -d "$run"
cd "$run"
sha256sum -c SHA256SUMS_v3.txt >/dev/null
mkdir -p integration_logs
cp "$here"/stage57_R012_*_candidate_20261125.v .
cp "$here"/SHA256SUMS integration_logs/input_SHA256SUMS.txt
cp "$here"/verify_integration.sh "$here"/version_check.txt "$here"/packages_check.txt integration_logs/
status=0
for name in product_bridge registered_slice affine_slice; do
 m=stage57_R012_${name}_candidate_20261125
 rm -f "$m.vo" "$m.vos" "$m.vok"
 if [ "$status" -ne 0 ]; then
   echo "HOLD: $m (predecessor failed)" | tee -a integration_logs/results.txt
   continue
 fi
 if opam exec -- coqc "$m.v" > "integration_logs/$m.coqc.log" 2>&1 && test -s "$m.vo" && opam exec -- coqchk "$m" > "integration_logs/$m.coqchk.log" 2>&1 && grep -q 'Modules were successfully checked' "integration_logs/$m.coqchk.log"; then
   echo "PASS: $m" | tee -a integration_logs/results.txt
 else
   echo "FAIL: $m" | tee -a integration_logs/results.txt
   tail -n 20 "integration_logs/$m.coqc.log"
   status=1
 fi
done
echo "RESULT STATUS: $status" | tee -a integration_logs/results.txt
find . -type f ! -name SHA256SUMS_integration.txt -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS_integration.txt
sha256sum -c SHA256SUMS_integration.txt >/dev/null
zip -qr "$run.zip" .
unzip -tq "$run.zip"
sha256sum "$run.zip"
echo "DOWNLOAD: $run.zip"
exit "$status"
