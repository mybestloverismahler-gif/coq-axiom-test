(* G4-03: adapter only; not yet machine checked. *)
Require Import Reals Coquelicot.Coquelicot.
Require Import stage57_R012_coordinate_bridge_candidate_20261125_v3.
Require Import stage57_R012_linear_dot_candidate_20261125_v2.
Module V := R001_R004_Conditional_Interpretation.
Definition r012_to_product (v : V.r002_vec3) : R012_space := V.r002_components v.
Lemma r012_product_roundtrip : forall v, V.r002_build (r012_to_product v) = v.
Proof. exact V.r002_build_components. Qed.
Lemma r012_product_add : forall u v,
  r012_to_product (V.r004_add u v) = plus (r012_to_product u) (r012_to_product v).
Proof. intros [x y z] [a b c]. reflexivity. Qed.
Lemma r012_product_scale : forall (a : R) v,
  r012_to_product (V.r003_scale a v) = scal a (r012_to_product v).
Proof. intros a [x y z]. reflexivity. Qed.
Print Assumptions r012_product_roundtrip.
Print Assumptions r012_product_add.
Print Assumptions r012_product_scale.
