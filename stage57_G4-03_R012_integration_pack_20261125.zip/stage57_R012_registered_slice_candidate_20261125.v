(* G4-03 / 9 of 42. UNCOMPILED. Local conditional adapter only.
   The three affine-line filterdiff hypotheses must still be established.
   No assertion of global partials_exist from differentiability at one point. *)
Require Import Reals Coquelicot.Coquelicot.
Require Import stage57_R011_derivative_contract_candidate_20261125.
Require Import stage57_R012_coordinate_bridge_candidate_20261125_v3.
Require Import stage57_R012_linear_dot_candidate_20261125_v2.
Require Import stage57_R012_product_bridge_candidate_20261125.
Module V := R001_R004_Conditional_Interpretation.
Definition registered_line_x (p : V.r002_vec3) (t : R) : R012_space :=
  (t, (V.y_component p, V.z_component p)).
Definition registered_line_y (p : V.r002_vec3) (t : R) : R012_space :=
  (V.x_component p, (t, V.z_component p)).
Definition registered_line_z (p : V.r002_vec3) (t : R) : R012_space :=
  (V.x_component p, (V.y_component p, t)).
Lemma registered_slice_x : forall f p t,
  R012_pull f (registered_line_x p t) = slice_x f p t.
Proof. reflexivity. Qed.
Lemma registered_slice_y : forall f p t,
  R012_pull f (registered_line_y p t) = slice_y f p t.
Proof. reflexivity. Qed.
Lemma registered_slice_z : forall f p t,
  R012_pull f (registered_line_z p t) = slice_z f p t.
Proof. reflexivity. Qed.
Lemma registered_partial_values : forall (f : R011_Field_Bridge.scalar_field)
    (p : V.r002_vec3) (D : R012_space -> R),
  filterdiff (R012_pull f) (locally (r012_to_product p)) D ->
  filterdiff (registered_line_x p) (locally (V.x_component p))
    (fun k : R => scal k (r012_to_product r012_ex)) ->
  filterdiff (registered_line_y p) (locally (V.y_component p))
    (fun k : R => scal k (r012_to_product r012_ey)) ->
  filterdiff (registered_line_z p) (locally (V.z_component p))
    (fun k : R => scal k (r012_to_product r012_ez)) ->
  dx3 f p = D (r012_to_product r012_ex) /\
  dy3 f p = D (r012_to_product r012_ey) /\
  dz3 f p = D (r012_to_product r012_ez).
Proof.
  intros f p D HF Hx Hy Hz. split.
  - unfold dx3.
    change (Derive (fun k : R => R012_pull f (registered_line_x p k))
      (V.x_component p) = D (r012_to_product r012_ex)).
    eapply r012_coordinate_value_candidate; [reflexivity|exact HF|exact Hx].
  - split.
    + unfold dy3.
      change (Derive (fun k : R => R012_pull f (registered_line_y p k))
        (V.y_component p) = D (r012_to_product r012_ey)).
      eapply r012_coordinate_value_candidate; [reflexivity|exact HF|exact Hy].
    + unfold dz3.
      change (Derive (fun k : R => R012_pull f (registered_line_z p k))
        (V.z_component p) = D (r012_to_product r012_ez)).
      eapply r012_coordinate_value_candidate; [reflexivity|exact HF|exact Hz].
Qed.
Print Assumptions registered_slice_x.
Print Assumptions registered_slice_y.
Print Assumptions registered_slice_z.
Print Assumptions registered_partial_values.
