(* G4-03 / 9 of 42. UNCOMPILED. Reuses Coquelicot affine rules. *)
Require Import Reals Coquelicot.Coquelicot Coq.Logic.FunctionalExtensionality.
Require Import stage57_R012_registered_slice_candidate_20261125.
Require Import stage57_R012_product_bridge_candidate_20261125.
Require Import stage57_R012_linear_dot_candidate_20261125_v2.
Require Import stage57_R012_coordinate_bridge_candidate_20261125_v3.
Open Scope R_scope.
Module AV := R001_R004_Conditional_Interpretation.
Lemma r012_affine_line_diff : forall (a e : R012_space) (t : R),
  filterdiff (fun k : R => plus a (scal k e)) (locally t)
    (fun k : R => scal k e).
Proof.
  intros a e t.
  eapply filterdiff_ext_lin with (l1 := fun k : R => plus zero (scal k e)).
  - apply filterdiff_plus_fct.
    + apply filterdiff_const.
    + apply filterdiff_scal_l.
  - intro k. apply plus_zero_l.
Qed.
Lemma r012_registered_line_x_diff : forall (p : AV.r002_vec3),
  filterdiff (registered_line_x p) (locally (AV.x_component p))
    (fun k : R => scal k (r012_to_product r012_ex)).
Proof.
  intro p.
  replace (registered_line_x p) with
    (fun k : R => plus ((0, (AV.y_component p, AV.z_component p)) : R012_space) (scal k (r012_to_product r012_ex))).
  - apply r012_affine_line_diff.
  - apply functional_extensionality. intro k.
    change (((0 + k * 1), ((AV.y_component p + k * 0), (AV.z_component p + k * 0))) = (k, (AV.y_component p, AV.z_component p))).
    repeat f_equal; unfold AV.r001_scalar, AV.carrier_for in *; simpl in *; ring.
Qed.
Lemma r012_registered_line_y_diff : forall (p : AV.r002_vec3),
  filterdiff (registered_line_y p) (locally (AV.y_component p))
    (fun k : R => scal k (r012_to_product r012_ey)).
Proof.
  intro p.
  replace (registered_line_y p) with
    (fun k : R => plus ((AV.x_component p, (0, AV.z_component p)) : R012_space) (scal k (r012_to_product r012_ey))).
  - apply r012_affine_line_diff.
  - apply functional_extensionality. intro k.
    change (((AV.x_component p + k * 0), ((0 + k * 1), (AV.z_component p + k * 0))) = (AV.x_component p, (k, AV.z_component p))).
    repeat f_equal; unfold AV.r001_scalar, AV.carrier_for in *; simpl in *; ring.
Qed.
Lemma r012_registered_line_z_diff : forall (p : AV.r002_vec3),
  filterdiff (registered_line_z p) (locally (AV.z_component p))
    (fun k : R => scal k (r012_to_product r012_ez)).
Proof.
  intro p.
  replace (registered_line_z p) with
    (fun k : R => plus ((AV.x_component p, (AV.y_component p, 0)) : R012_space) (scal k (r012_to_product r012_ez))).
  - apply r012_affine_line_diff.
  - apply functional_extensionality. intro k.
    change (((AV.x_component p + k * 0), ((AV.y_component p + k * 0), (0 + k * 1))) = (AV.x_component p, (AV.y_component p, k))).
    repeat f_equal; unfold AV.r001_scalar, AV.carrier_for in *; simpl in *; ring.
Qed.
Print Assumptions r012_affine_line_diff.
Print Assumptions r012_registered_line_x_diff.
Print Assumptions r012_registered_line_y_diff.
Print Assumptions r012_registered_line_z_diff.
