From Coquelicot Require Import Coquelicot.
Locate filterdiff.
Print filterdiff.
Locate is_linear.
Print is_linear.
Search filterdiff.
Search is_linear.
Search ex_derive.
