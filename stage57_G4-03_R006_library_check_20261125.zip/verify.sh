#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
sha256sum -c SHA256SUMS
run=$(mktemp -d "$PWD/run.XXXXXXXX")
cp -- *.v SHA256SUMS "$run/"
cd "$run"
mkdir logs
opam exec -- coqc --version | tee logs/version.txt
opam list --installed --columns=name,version > logs/opam.txt
grep -q 'version 8\.18\.0' logs/version.txt
grep -Eq '^coq-coquelicot[[:space:]]+3\.4\.5([[:space:]]|$)' logs/opam.txt
status=0
for f in stage57_T3_T4_U1_candidate stage57_R001_R004_interpretation_candidate_v2_20261122 stage57_R006_component_dot_candidate_20261125; do
  if ! opam exec -- coqc "$f.v" > "logs/$f.coqc.log" 2>&1; then
    tail -n 25 "logs/$f.coqc.log"; status=1; break
  fi
  test -s "$f.vo"
done
if [ "$status" = 0 ]; then
  if opam exec -- coqchk stage57_R006_component_dot_candidate_20261125 > logs/dot.coqchk.log 2>&1 && grep -F 'Modules were successfully checked' logs/dot.coqchk.log; then
    echo 'PASS: R006 machine check'
  else status=1; fi
fi
cat logs/stage57_R006_component_dot_candidate_20261125.coqc.log 2>/dev/null || true
if opam exec -- coqc library_probe.v > logs/library_probe.log 2>&1; then
  echo 'PASS: library probe'
else tail -n 25 logs/library_probe.log; status=1; fi
root=$(opam exec -- coqc -where)
find "$root/user-contrib/Coquelicot" -type f -name '*.v' -print > logs/library_sources.txt
if [ -s logs/library_sources.txt ]; then
  xargs -d '\n' grep -nE '^(Definition|Lemma|Theorem|Record|Class) (filterdiff|is_linear|ex_derive|filterdiff_[[:alnum:]_]+)' < logs/library_sources.txt > logs/library_index.txt || true
  xargs -d '\n' sha256sum < logs/library_sources.txt > logs/library_sources_sha256.txt
fi
sha256sum -c SHA256SUMS
printf '%s\n' "$status" > logs/exit_status.txt
find . -type f ! -name SHA256SUMS_results.txt -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS_results.txt
sha256sum -c SHA256SUMS_results.txt >/dev/null
z="$(dirname "$run")/../stage57_G4-03_R006_library_verified_20261125.zip"
test ! -e "$z" || { echo 'Existing result ZIP: not overwritten'; exit 1; }
zip -qr "$z" .
unzip -t "$z" | tail -n 2
sha256sum "$z"
echo "RESULT STATUS: $status"
exit "$status"
