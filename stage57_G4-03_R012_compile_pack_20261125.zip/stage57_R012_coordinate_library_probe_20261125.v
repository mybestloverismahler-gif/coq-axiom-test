From Coquelicot Require Import Coquelicot.
Print is_derive.
Check is_derive_unique.
Check Derive_correct.
Check prod_NormedModule.
Check R_NormedModule.
Check locally_filter.
Check filterdiff_comp'.
Check filterdiff_ext_lin.
Check filterdiff_scal_l.
Check filterdiff_const.
Check filterdiff_plus_fct.
Check linear_scal.
Print Assumptions is_derive_unique.
Print Assumptions filterdiff_comp'.
Print Assumptions filterdiff_ext_lin.
Print Assumptions filterdiff_scal_l.
Print Assumptions filterdiff_const.
Print Assumptions filterdiff_plus_fct.
