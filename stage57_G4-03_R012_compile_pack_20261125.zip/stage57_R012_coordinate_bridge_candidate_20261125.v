(* G4-03: conditional coordinate-value bridge; UNCOMPILED.
   The affine slice derivative, product module compatibility and local
   total derivative are hypotheses, not established by this file. *)
Require Import Reals Coquelicot.Coquelicot.
Require Import stage57_R001_R004_interpretation_candidate_v2_20261122.
Require Import stage57_R011_derivative_contract_candidate_20261125.
Module C := R001_R004_Conditional_Interpretation.
Definition R012_pair := prod_NormedModule R_AbsRing R_NormedModule R_NormedModule.
Definition R012_space := prod_NormedModule R_AbsRing R_NormedModule R012_pair.
Definition R012_pull (f : C.r002_vec3 -> R) (u : R012_space) : R :=
  f (C.r002_build u).
(* Generic coordinate line; the caller must prove its affine derivative
   and its equality to the registered slice. *)
Lemma r012_coordinate_value_candidate :
  forall (F D : R012_space -> R) (p e : R012_space)
         (line : R -> R012_space) (t : R),
    line t = p ->
    filterdiff F (locally p) D ->
    filterdiff line (locally t) (fun k : R => scal k e) ->
    Derive (fun k : R => F (line k)) t = D e.
Proof.
  intros F D p e line t Hp HF Hl.
  pose proof (proj1 HF) as HD.
  rewrite <- Hp in HF.
  pose proof (filterdiff_comp' line F t (fun k : R => scal k e) D Hl HF) as HC.
  assert (HH : is_derive (fun k : R => F (line k)) t (D e)).
  { unfold is_derive.
    eapply filterdiff_ext_lin; [apply locally_filter|exact HC|].
    intro k. apply linear_scal. exact HD. }
  apply is_derive_unique. exact HH.
Qed.
Print Assumptions r012_coordinate_value_candidate.
