(* G3-02: candidate only, not compiled. Whole-space scope.
   Reuses existing R011 assembly and Coquelicot coordinate derivatives.
   No claim of derivation from original axioms, C1, or decidability. *)
Require Import Reals Coquelicot.Coquelicot.
Require Import stage57_R001_R004_interpretation_candidate_v2_20261122.
Require Import stage57_R011_field_bridge_candidate_20261125.
Module B := R011_Field_Bridge.
Module C := R001_R004_Conditional_Interpretation.
Definition slice_x (f : B.scalar_field) (p : C.r002_vec3) (t : R) : R :=
  f (C.R002_vec3 t (C.y_component p) (C.z_component p)).
Definition slice_y (f : B.scalar_field) (p : C.r002_vec3) (t : R) : R :=
  f (C.R002_vec3 (C.x_component p) t (C.z_component p)).
Definition slice_z (f : B.scalar_field) (p : C.r002_vec3) (t : R) : R :=
  f (C.R002_vec3 (C.x_component p) (C.y_component p) t).
Definition dx3 (f : B.scalar_field) : B.scalar_field :=
  fun p => Derive (slice_x f p) (C.x_component p).
Definition dy3 (f : B.scalar_field) : B.scalar_field :=
  fun p => Derive (slice_y f p) (C.y_component p).
Definition dz3 (f : B.scalar_field) : B.scalar_field :=
  fun p => Derive (slice_z f p) (C.z_component p).
Definition partials_exist (f : B.scalar_field) : Prop :=
  forall p, ex_derive (slice_x f p) (C.x_component p) /\
            ex_derive (slice_y f p) (C.y_component p) /\
            ex_derive (slice_z f p) (C.z_component p).
Definition partial_contract (f dx dy dz : B.scalar_field) : Prop :=
  partials_exist f /\ dx = dx3 f /\ dy = dy3 f /\ dz = dz3 f.
Lemma supplied_partials_contract : forall f, partials_exist f ->
  partial_contract f (dx3 f) (dy3 f) (dz3 f).
Proof. intros f H. unfold partial_contract. split. exact H. repeat split; reflexivity. Qed.
Definition grad3 (f : B.scalar_field) (H : partials_exist f) : B.vector_field :=
  B.assemble_grad partial_contract f (dx3 f) (dy3 f) (dz3 f)
    (supplied_partials_contract f H).
Lemma grad3_components : forall f (H : partials_exist f) p,
  C.r002_components (grad3 f H p) = (dx3 f p, (dy3 f p, dz3 f p)).
Proof. reflexivity. Qed.
Print Assumptions supplied_partials_contract.
Print Assumptions grad3_components.
