#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
sha256sum -c SHA256SUMS
mkdir logs
opam exec -- coqc --version > logs/version.txt
opam list --installed > logs/opam.txt
cat logs/version.txt
 grep -Eq 'version 8\.18\.0' logs/version.txt
 grep -Eq '^coq-coquelicot[[:space:]]+3\.4\.5([[:space:]]|$)' logs/opam.txt
status=0
run() {
  local f=$1
  if opam exec -- coqc "$f.v" > "logs/$f.coqc.log" 2>&1 && test -s "$f.vo"; then
    echo "PASS coqc $f"
  else
    echo "FAIL coqc $f"; tail -n 12 "logs/$f.coqc.log"; status=1; return 1
  fi
}
check() {
  local f=$1
  if opam exec -- coqchk "$f" > "logs/$f.coqchk.log" 2>&1 && grep -q 'Modules were successfully checked' "logs/$f.coqchk.log"; then
    echo "PASS coqchk $f"
  else
    echo "FAIL coqchk $f"; status=1
  fi
}
run stage57_T3_T4_U1_candidate || true
run stage57_R001_R004_interpretation_candidate_v2_20261122 || true
run stage57_R006_component_dot_candidate_20261125 || true
run stage57_R011_field_bridge_candidate_20261125 || true
run stage57_R011_derivative_contract_candidate_20261125 || true
run stage57_R012_coordinate_library_probe_20261125 || true
for f in stage57_R012_linear_dot_candidate_20261125 stage57_R012_coordinate_bridge_candidate_20261125; do
  if run "$f"; then check "$f"; fi
done
sha256sum -c SHA256SUMS
printf 'RESULT STATUS: %s\n' "$status" | tee logs/result.txt
find . -type f ! -name SHA256SUMS_result.txt -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS_result.txt
sha256sum -c SHA256SUMS_result.txt > /dev/null
z=$(mktemp "$root/stage57_G4-03_R012_result_20261125.XXXXXXXX")
rm "$z"
z="$z.zip"
zip -qr "$z" .
unzip -tq "$z"
sha256sum "$z"
echo "DOWNLOAD: $z"
exit "$status"
