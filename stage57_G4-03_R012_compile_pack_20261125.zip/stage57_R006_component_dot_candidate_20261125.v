(* G4-03 / 9 of 42. Candidate only; no original-axiom closure.
   R006 A050: fixed Cartesian Euclidean basis, component form, zero allowed.
   Units and orthonormality are external guards, not encoded here. *)
From Coq Require Import Reals.
Require Import stage57_R001_R004_interpretation_candidate_v2_20261122.
Import R001_R004_Conditional_Interpretation.

Definition r006_dot_components (u v : r002_vec3) : r001_scalar :=
  Rplus (Rplus (Rmult (x_component u) (x_component v))
               (Rmult (y_component u) (y_component v)))
        (Rmult (z_component u) (z_component v)).

Lemma r006_dot_build : forall ax ay az bx b_y bz : r001_scalar,
  r006_dot_components (R002_vec3 ax ay az) (R002_vec3 bx b_y bz) =
  Rplus (Rplus (Rmult ax bx) (Rmult ay b_y)) (Rmult az bz).
Proof. reflexivity. Qed.

Lemma r006_dot_roundtrip : forall u v : r002_vec3,
  r006_dot_components (r002_build (r002_components u))
                      (r002_build (r002_components v)) =
  r006_dot_components u v.
Proof. intros u v. repeat rewrite r002_build_components. reflexivity. Qed.

Print Assumptions r006_dot_build.
Print Assumptions r006_dot_roundtrip.
