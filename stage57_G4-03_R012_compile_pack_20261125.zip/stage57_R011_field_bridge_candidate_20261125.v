(* G3-02 / R011. Candidate, not compiled. Existing carriers reused.
   This is only a typed constructor from supplied derivative fields,
   not a differentiation algorithm or a proof of differentiability. *)
Require Import Coq.Strings.String.
Require Import stage57_R001_R004_interpretation_candidate_v2_20261122.
Module C := R001_R004_Conditional_Interpretation.
Module R011_Field_Bridge.
Definition scalar_field := C.r002_vec3 -> C.r001_scalar.
Definition vector_field := C.r002_vec3 -> C.r002_vec3.
(* The predicate is supplied by the eventual verified analytic interface.
   No assertion that it holds, is decidable, or is the intended C1 predicate. *)
Section Conditional.
Variable derivative_contract : scalar_field -> scalar_field -> scalar_field -> scalar_field -> Prop.
Definition assemble_grad (f dx dy dz : scalar_field)
  (_ : derivative_contract f dx dy dz) : vector_field :=
  fun p => C.R002_vec3 (dx p) (dy p) (dz p).
Lemma grad_components : forall f dx dy dz (H : derivative_contract f dx dy dz) p,
  C.r002_components (assemble_grad f dx dy dz H p) = (dx p, (dy p, dz p)).
Proof. reflexivity. Qed.
End Conditional.
End R011_Field_Bridge.
Print Assumptions R011_Field_Bridge.grad_components.
