(* G4-03 / 9 of 42. Uncompiled conditional algebra adapter.
   Not a proof of differentiability, coordinate derivative agreement,
   orthonormality, units, or derivation from original axioms. *)
From Coq Require Import Reals Ring.
Require Import stage57_R001_R004_interpretation_candidate_v2_20261122.
Require Import stage57_R006_component_dot_candidate_20261125.
Import R001_R004_Conditional_Interpretation.
Open Scope R_scope.

Definition r012_ex : r002_vec3 := R002_vec3 1 0 0.
Definition r012_ey : r002_vec3 := R002_vec3 0 1 0.
Definition r012_ez : r002_vec3 := R002_vec3 0 0 1.

Lemma r012_basis_expand : forall h : r002_vec3,
  h = r004_add
        (r004_add (r003_scale (x_component h) r012_ex)
                  (r003_scale (y_component h) r012_ey))
        (r003_scale (z_component h) r012_ez).
Proof.
  intros [x y z].
  unfold r004_add, r003_scale, r012_ex, r012_ey, r012_ez.
  simpl. f_equal; ring.
Qed.

Lemma r012_linear_dot : forall (D : r002_vec3 -> r001_scalar),
  (forall u v, D (r004_add u v) = D u + D v) ->
  (forall a v, D (r003_scale a v) = a * D v) ->
  forall h, D h = r006_dot_components
    (R002_vec3 (D r012_ex) (D r012_ey) (D r012_ez)) h.
Proof.
  intros D Hplus Hscale h.
  pose proof (r012_basis_expand h) as E.
  rewrite E at 1.
  repeat rewrite Hplus.
  repeat rewrite Hscale.
  unfold r006_dot_components. simpl. ring.
Qed.
Print Assumptions r012_basis_expand.
Print Assumptions r012_linear_dot.
